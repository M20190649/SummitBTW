@javax.xml.bind.annotation.XmlSchema(namespace = "http://ws.tudresden.de/")
package de.tudresden.ws;
